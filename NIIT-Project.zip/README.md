# NIIT Project
Project Name: Censono
Version	: V1.1
Start Date	: December 22, 2022
End Date	: January 15, 2023
Name of Coordinator	: Mr. Fredrick 
Name of Developer	: Matur Innocent J.



Date of Submission	: January 17, 2023
